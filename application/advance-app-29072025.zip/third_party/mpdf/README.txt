About
============

This is the latest mpdf 5.7, with obsolete constructor names replaced by __construct (compatibility with PHP7 without warnings).

Upgrading
============

To upgrade from mPDF 5.7.3 to 5.7.4, simply upload the files to their corresponding folders, overwriting files as required.

