
        </div>
		
		<?php $this->load->view('admin/includes/footerfiles');?>
		<?php $this->load->view('admin/includes/modal');?>
		
	</body>
</html>