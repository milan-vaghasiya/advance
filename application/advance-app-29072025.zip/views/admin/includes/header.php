<!DOCTYPE html>
<html dir="ltr" lang="en">
<?php $this->load->view('admin/includes/headerfiles'); ?>
	<body id="body" class="dark-sidebar">
		<div class="preloader">
			<div class="lds-ripple">
				<div class="lds-pos"></div>
				<div class="lds-pos"></div>
			</div>
		</div>
		<?php $this->load->view('admin/includes/topbar'); ?>
		<?php $this->load->view('admin/includes/sidebar'); ?>
    	<div class="page-wrapper">
			