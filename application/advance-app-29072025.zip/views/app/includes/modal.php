<div class="modal fade show" id="modalCenter" aria-modal="true" role="dialog" style="display: none;"  data-bs-backdrop="static" data-bs-keyboard="false">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header border-0 pb-0">
                <h5 class="modal-title">ADD CARD</h5>
                <button class="btn-close" data-bs-dismiss="modal">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>
            <div class="modal-body">
              
            </div>
            <div class="modal-footer">
            <a href="javascript:void(0);" class="btn btn-sm btn-danger" data-bs-dismiss="modal">Close</a>
            <a href="javascript:void(0);" class="btn btn-sm btn-primary btn-save">Save</a>
            </div>
        </div>
    </div>
</div>
<div class="modal fade show" id="modalLong"  aria-modal="true" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Modal title</h5>
                <button class="btn-close" data-bs-dismiss="modal">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>
            <div class="modal-body">
               
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-sm btn-danger light" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-sm btn-primary btn-save">Save changes</button>
            </div>
        </div>
    </div>
</div>